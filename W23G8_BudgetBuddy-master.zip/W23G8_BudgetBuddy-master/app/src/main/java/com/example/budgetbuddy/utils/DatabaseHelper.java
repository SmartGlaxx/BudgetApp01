package com.example.budgetbuddy.utils;

import static com.example.budgetbuddy.constants.Constants.COLUMN_AMOUNT_EXPENSE;
import static com.example.budgetbuddy.constants.Constants.COLUMN_AMOUNT_INCOME;
import static com.example.budgetbuddy.constants.Constants.COLUMN_DATE_EXPENSE;
import static com.example.budgetbuddy.constants.Constants.COLUMN_DATE_INCOME;
import static com.example.budgetbuddy.constants.Constants.COLUMN_DESCRIPTION_EXPENSE;
import static com.example.budgetbuddy.constants.Constants.COLUMN_DESCRIPTION_INCOME;
import static com.example.budgetbuddy.constants.Constants.CREATE_INCOME_TABLE;
import static com.example.budgetbuddy.constants.Constants.DATABASE_NAME;
import static com.example.budgetbuddy.constants.Constants.DATABASE_VERSION;
import static com.example.budgetbuddy.constants.Constants.TABLE_INCOME;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.budgetbuddy.constants.Constants;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //create table in DB
        db.execSQL(CREATE_INCOME_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //drop table if it exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INCOME);
        //create table again
        onCreate(db);
    }

    //insert income into DB
    public long insertIncome(String income, String incomeDescription, String incomeDate){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_AMOUNT_INCOME, income);
        contentValues.put(COLUMN_DESCRIPTION_INCOME, incomeDescription);
        contentValues.put(COLUMN_DATE_INCOME, incomeDate);

        long id = db.insert(TABLE_INCOME, null, contentValues);

        db.close();

        return id;

    }

    public long insertExpense(String expense, String expenseDescription, String expenseDate){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_AMOUNT_EXPENSE, expense);
        contentValues.put(COLUMN_DESCRIPTION_EXPENSE, expenseDescription);
        contentValues.put(COLUMN_DATE_EXPENSE, expenseDate);

        long id = db.insert(TABLE_INCOME, null, contentValues);

        db.close();

        return id;

    }

}
