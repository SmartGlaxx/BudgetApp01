package com.example.budgetbuddy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddExpenseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);
    }
}