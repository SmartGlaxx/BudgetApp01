package com.example.budgetbuddy.Model;

public class Expense {
    private int id;
    private int expense;
    private String expenseDescription;
    private String expenseDate;

    public Expense() {
    }
    public Expense(int expense, String expenseDescription, String expenseDate) {
        this.expense = expense;
        this.expenseDescription = expenseDescription;
        this.expenseDate = expenseDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getExpense() {
        return expense;
    }

    public void setExpense(int expense) {
        this.expense = expense;
    }

    public String getExpenseDescription() {
        return expenseDescription;
    }

    public void setExpenseDescription(String expenseDescription) {
        this.expenseDescription = expenseDescription;
    }

    public String getExpenseDate() {
        return expenseDate;
    }

    public void setExpenseDate(String expenseDate) {
        this.expenseDate = expenseDate;
    }
}
