package com.example.budgetbuddy.Model;

public class Income {
    private int id;
    private String income;
    private String incomeDescription;
    private String incomeDate;

    public Income() {
    }

    public Income(String income, String incomeDescription, String incomeDate) {
        this.income = income;
        this.incomeDescription = incomeDescription;
        this.incomeDate = incomeDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }

    public String getIncomeDescription() {
        return incomeDescription;
    }
    public void setIncomeDescription(String incomeDescription) {
        this.incomeDescription = incomeDescription;
    }
    public String getIncomeDate() {
        return incomeDate;
    }

    public void setIncomeDate(String incomeDate) {
        this.incomeDate = incomeDate;
    }
}
