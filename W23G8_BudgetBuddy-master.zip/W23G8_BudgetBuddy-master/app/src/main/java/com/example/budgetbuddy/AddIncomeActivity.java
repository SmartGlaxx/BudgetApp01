package com.example.budgetbuddy;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.icu.util.Calendar;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.budgetbuddy.constants.Constants;
import com.example.budgetbuddy.utils.DatabaseHelper;


public class AddIncomeActivity extends AppCompatActivity {

    public DatabaseHelper databaseHelper = new DatabaseHelper(this);;
    EditText editTextIncome;
    EditText editTextDescription;
    EditText editTextDate;
    Button btnAddIncome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_income);
        editTextIncome = findViewById(R.id.editTextIncome);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextDate = findViewById(R.id.editTextDate);
        btnAddIncome = findViewById(R.id.btnAddExpense);


        editTextDate.setInputType(InputType.TYPE_CLASS_DATETIME);
        editTextDate.setTextIsSelectable(true);

        editTextDate.addTextChangedListener(new TextWatcher() {
            private String current = "";
            private String ddmmyyyy = "DDMMYYYY";
            private Calendar cal = Calendar.getInstance();

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals(current)) {
                    String clean = s.toString().replaceAll("[^\\d.]", "");
                    String cleanC = current.replaceAll("[^\\d.]", "");

                    int cl = clean.length();
                    int sel = cl;
                    for (int i = 2; i <= cl && i < 6; i += 2) {
                        sel++;
                    }
                    if (clean.equals(cleanC)) sel--;

                    if (clean.length() < 8) {
                        clean = clean + ddmmyyyy.substring(clean.length());
                    } else {
                        int day = Integer.parseInt(clean.substring(0, 2));
                        int mon = Integer.parseInt(clean.substring(2, 4));
                        int year = Integer.parseInt(clean.substring(4, 8));

                        if (mon > 12) mon = 12;
                        cal.set(Calendar.MONTH, mon - 1);
                        year = (year < 1900) ? 1900 : (year > 2100) ? 2100 : year;
                        cal.set(Calendar.YEAR, year);

                        day = (day > cal.getActualMaximum(Calendar.DATE)) ? cal.getActualMaximum(Calendar.DATE) : day;
                        clean = String.format("%02d%02d%02d", day, mon, year);

                        // validate the date
                        Calendar currentDate = Calendar.getInstance();
                        currentDate.set(Calendar.HOUR_OF_DAY, 0);
                        currentDate.set(Calendar.MINUTE, 0);
                        currentDate.set(Calendar.SECOND, 0);
                        currentDate.set(Calendar.MILLISECOND, 0);
                        if (cal.after(currentDate)) {
                            editTextDate.setError("Invalid date");
                            editTextDate.requestFocus();
                            return;
                        }
                    }

                    clean = String.format("%s/%s/%s", clean.substring(0, 2),
                            clean.substring(2, 4),
                            clean.substring(4, 8));

                    sel = Math.max(sel, 0);
                    current = clean;
                    editTextDate.setText(current);
                    editTextDate.setSelection(Math.min(sel, current.length()));
                }
            }
        });


        btnAddIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(editTextIncome.getText().toString().equalsIgnoreCase("0")){
                    Toast.makeText(AddIncomeActivity.this, "Income cannot be 0", Toast.LENGTH_SHORT).show();
                }
                if(editTextDescription.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(AddIncomeActivity.this, "Please enter a description" + editTextDescription.getText().toString(), Toast.LENGTH_SHORT).show();
                }
                if(editTextDate.getText().toString().toLowerCase().contains("d") ||
                        editTextDate.getText().toString().toLowerCase().contains("m") ||
                        editTextDate.getText().toString().toLowerCase().contains("y")){
                    Toast.makeText(AddIncomeActivity.this, "Please enter a valid date", Toast.LENGTH_SHORT).show();
                    return;
                }
              if(!editTextIncome.getText().toString().equalsIgnoreCase("") && !editTextDescription.getText().toString().equalsIgnoreCase("") && !editTextDate.getText().toString().equalsIgnoreCase("")){

                  String income = editTextIncome.getText().toString();
                  String incomeDescription = editTextDescription.getText().toString();
                  String incomeDate = editTextDate.getText().toString();

                  long insertedId = databaseHelper.insertIncome(income, incomeDescription, incomeDate);
                    try{
                        if (isDataInserted()) {
                            Toast.makeText(AddIncomeActivity.this, "Income added successfully in row: ", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(AddIncomeActivity.this, "Error adding income", Toast.LENGTH_LONG).show();
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                        Toast.makeText(AddIncomeActivity.this, "Exception", Toast.LENGTH_SHORT).show();
                    }
                  Toast.makeText(AddIncomeActivity.this, "Not Empty", Toast.LENGTH_SHORT).show();
              }else{
                  Toast.makeText(AddIncomeActivity.this, "Empty/invalid input", Toast.LENGTH_SHORT).show();
              }
            }


        });

    }

    public boolean isDataInserted() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String query = "SELECT * FROM " + Constants.TABLE_INCOME;
        Cursor cursor = db.rawQuery(query, null);
        boolean isInserted = cursor.moveToFirst();
        cursor.close();
        db.close();
        return isInserted;
    }


}