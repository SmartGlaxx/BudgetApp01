package com.example.budgetbuddy;

import static com.example.budgetbuddy.constants.Constants.COLUMN_AMOUNT_INCOME;
import static com.example.budgetbuddy.constants.Constants.COLUMN_DATE_INCOME;
import static com.example.budgetbuddy.constants.Constants.COLUMN_DESCRIPTION_INCOME;
import static com.example.budgetbuddy.constants.Constants.COLUMN_ID_INCOME;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.budgetbuddy.Model.Income;
import com.example.budgetbuddy.constants.Constants;
import com.example.budgetbuddy.utils.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class BudgetReportActivity extends AppCompatActivity {

    List<Income> IncomeList = new ArrayList<Income>();
    ListView listViewBudgetReport;
    String[] projection = {
            COLUMN_AMOUNT_INCOME,
            COLUMN_DESCRIPTION_INCOME,
            COLUMN_DATE_INCOME
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget_report);

        listViewBudgetReport = findViewById(R.id.listViewBudgetReport);
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.query(
                Constants.TABLE_INCOME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor.moveToFirst()) {
            do {
                String income = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AMOUNT_INCOME));
                String incomeDescription = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION_INCOME));
                String incomeDate = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE_INCOME));

                setIncomeValues(income, incomeDescription, incomeDate);
                BudgetReportAdapter BudgetAdapter = new BudgetReportAdapter(IncomeList);
                Toast.makeText(this, "" + incomeDescription + " on : " + incomeDate, Toast.LENGTH_SHORT).show();
                listViewBudgetReport.setAdapter(BudgetAdapter);
            } while (cursor.moveToNext());
        }


    }

    public void setIncomeValues(String income, String incomeDescription, String incomeDate){
        for(int i=0; i < 1; i++){
            IncomeList.add(new Income(income, incomeDescription, incomeDate));
        }
    }
}